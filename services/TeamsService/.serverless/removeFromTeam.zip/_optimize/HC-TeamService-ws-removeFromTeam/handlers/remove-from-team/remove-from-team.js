(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.handler = f()}})(function(){var define,module,exports;return (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";const AWS=require("aws-sdk"),db=new AWS.DynamoDB.DocumentClient,TableName=process.env.PROFILES_TABLE;class ProfilesTable{static async getProfileAsync(profileId){return(await db.query({TableName,KeyConditionExpression:"id = :id",ExpressionAttributeValues:{":id":profileId}}).promise()).Items[0]}static async getBatchProfilesAsync(users){const params={RequestItems:{[TableName]:{Keys:users.map(u=>({id:u}))}}};return(await db.batchGet(params).promise()).Responses[TableName]}static async addTeamAsync(teamId,profileId){return await db.update({TableName,Key:{id:profileId},UpdateExpression:`SET teams = list_append(teams, :teamId)`,ExpressionAttributeValues:{":teamId":[teamId]},ReturnValues:"ALL_NEW"}).promise()}static async updateTeamsAsync(userId,teams){return(await db.update({TableName,Key:{id:userId},UpdateExpression:`SET teams = :teams`,ExpressionAttributeValues:{":teams":teams},ReturnValues:"ALL_NEW"}).promise()).Attributes}}module.exports=ProfilesTable;

},{"aws-sdk":undefined}],2:[function(require,module,exports){
"use strict";const AWS=require("aws-sdk"),uuid=require("uuid/v4"),db=new AWS.DynamoDB.DocumentClient,TableName=process.env.TEAMS_TABLE;class TeamsTable{static async createTeamAsync(code,name,categories){const id=uuid(),params={TableName,Item:{id,name,code,users:[],categories}};return await db.put(params).promise(),params.Item}static async queryTeamByCodeAsync(code){return(await db.query({TableName,IndexName:"gsi_code",KeyConditionExpression:"code = :code",ExpressionAttributeValues:{":code":code}}).promise()).Items}static async queryTeamByIdAsync(teamId){const response=await db.query({TableName,KeyConditionExpression:"id = :id",ExpressionAttributeValues:{":id":teamId}}).promise();return response.Items[0]}static async findBatchTeamsAsync(teams){const params={RequestItems:{[process.env.TEAMS_TABLE]:{Keys:teams.map(t=>({id:t}))}}};return(await db.batchGet(params).promise()).Responses[TableName]}static async addProfileAsync(teamId,profileId){return(await db.update({TableName,Key:{id:teamId},UpdateExpression:`SET #u = list_append(#u, :profileId)`,ExpressionAttributeValues:{":profileId":[profileId]},ExpressionAttributeNames:{"#u":"users"},ReturnValues:"ALL_NEW"}).promise()).Attributes}static async updateProfilesAsync(teamId,users){return(await db.update({TableName,Key:{id:teamId},UpdateExpression:`SET #u = :users`,ExpressionAttributeValues:{":users":users},ExpressionAttributeNames:{"#u":"users"},ReturnValues:"ALL_NEW"}).promise()).Attributes}}module.exports=TeamsTable;

},{"aws-sdk":undefined,"uuid/v4":6}],3:[function(require,module,exports){
"use strict";const ProfilesTable=require("../../db/ProfilesTable"),TeamsTable=require("../../db/TeamsTable");module.exports.lambda=async event=>{const{teamId,removedUserId}=JSON.parse(event.body),team=await TeamsTable.queryTeamByIdAsync(teamId),remainingUsers=team.users.filter(u=>u!==removedUserId),user=await ProfilesTable.getProfileAsync(removedUserId),remainingTeams=user.teams.filter(t=>t!==teamId);try{const updatedTeam=await TeamsTable.updateProfilesAsync(teamId,remainingUsers);return await ProfilesTable.updateTeamsAsync(removedUserId,remainingTeams),{statusCode:200,body:JSON.stringify(updatedTeam)}}catch(e){return{statusCode:500,body:"Unable to update team users"}}};

},{"../../db/ProfilesTable":1,"../../db/TeamsTable":2}],4:[function(require,module,exports){
/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */
var byteToHex = [];
for (var i = 0; i < 256; ++i) {
  byteToHex[i] = (i + 0x100).toString(16).substr(1);
}

function bytesToUuid(buf, offset) {
  var i = offset || 0;
  var bth = byteToHex;
  // join used to fix memory issue caused by concatenation: https://bugs.chromium.org/p/v8/issues/detail?id=3175#c4
  return ([bth[buf[i++]], bth[buf[i++]], 
	bth[buf[i++]], bth[buf[i++]], '-',
	bth[buf[i++]], bth[buf[i++]], '-',
	bth[buf[i++]], bth[buf[i++]], '-',
	bth[buf[i++]], bth[buf[i++]], '-',
	bth[buf[i++]], bth[buf[i++]],
	bth[buf[i++]], bth[buf[i++]],
	bth[buf[i++]], bth[buf[i++]]]).join('');
}

module.exports = bytesToUuid;

},{}],5:[function(require,module,exports){
// Unique ID creation requires a high quality random # generator.  In node.js
// this is pretty straight-forward - we use the crypto API.

var crypto = require('crypto');

module.exports = function nodeRNG() {
  return crypto.randomBytes(16);
};

},{"crypto":undefined}],6:[function(require,module,exports){
var rng = require('./lib/rng');
var bytesToUuid = require('./lib/bytesToUuid');

function v4(options, buf, offset) {
  var i = buf && offset || 0;

  if (typeof(options) == 'string') {
    buf = options === 'binary' ? new Array(16) : null;
    options = null;
  }
  options = options || {};

  var rnds = options.random || (options.rng || rng)();

  // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`
  rnds[6] = (rnds[6] & 0x0f) | 0x40;
  rnds[8] = (rnds[8] & 0x3f) | 0x80;

  // Copy bytes to buffer, if provided
  if (buf) {
    for (var ii = 0; ii < 16; ++ii) {
      buf[i + ii] = rnds[ii];
    }
  }

  return buf || bytesToUuid(rnds);
}

module.exports = v4;

},{"./lib/bytesToUuid":4,"./lib/rng":5}]},{},[3])(3)
});

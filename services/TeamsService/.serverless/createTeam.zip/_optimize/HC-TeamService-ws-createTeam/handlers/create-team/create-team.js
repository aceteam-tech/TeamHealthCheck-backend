(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.handler = f()}})(function(){var define,module,exports;return (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";const AWS=require("aws-sdk"),db=new AWS.DynamoDB.DocumentClient,TableName=process.env.PROFILES_TABLE;class ProfilesTable{static async getProfileAsync(profileId){return(await db.query({TableName,KeyConditionExpression:"id = :id",ExpressionAttributeValues:{":id":profileId}}).promise()).Items[0]}static async getBatchProfilesAsync(users){const params={RequestItems:{[TableName]:{Keys:users.map(u=>({id:u}))}}};return(await db.batchGet(params).promise()).Responses[TableName]}static async addTeamAsync(teamId,profileId){return await db.update({TableName,Key:{id:profileId},UpdateExpression:`SET teams = list_append(teams, :teamId)`,ExpressionAttributeValues:{":teamId":[teamId]},ReturnValues:"ALL_NEW"}).promise()}static async updateTeamsAsync(userId,teams){return(await db.update({TableName,Key:{id:userId},UpdateExpression:`SET teams = :teams`,ExpressionAttributeValues:{":teams":teams},ReturnValues:"ALL_NEW"}).promise()).Attributes}}module.exports=ProfilesTable;

},{"aws-sdk":undefined}],2:[function(require,module,exports){
"use strict";const AWS=require("aws-sdk"),uuid=require("uuid/v4"),db=new AWS.DynamoDB.DocumentClient,TableName=process.env.TEAMS_TABLE;class TeamsTable{static async createTeamAsync(code,name,categories){const id=uuid(),params={TableName,Item:{id,name,code,users:[],categories}};return await db.put(params).promise(),params.Item}static async queryTeamByCodeAsync(code){return(await db.query({TableName,IndexName:"gsi_code",KeyConditionExpression:"code = :code",ExpressionAttributeValues:{":code":code}}).promise()).Items}static async queryTeamByIdAsync(teamId){const response=await db.query({TableName,KeyConditionExpression:"id = :id",ExpressionAttributeValues:{":id":teamId}}).promise();return response.Items[0]}static async findBatchTeamsAsync(teams){const params={RequestItems:{[process.env.TEAMS_TABLE]:{Keys:teams.map(t=>({id:t}))}}};return(await db.batchGet(params).promise()).Responses[TableName]}static async addProfileAsync(teamId,profileId){return(await db.update({TableName,Key:{id:teamId},UpdateExpression:`SET #u = list_append(#u, :profileId)`,ExpressionAttributeValues:{":profileId":[profileId]},ExpressionAttributeNames:{"#u":"users"},ReturnValues:"ALL_NEW"}).promise()).Attributes}static async updateProfilesAsync(teamId,users){return(await db.update({TableName,Key:{id:teamId},UpdateExpression:`SET #u = :users`,ExpressionAttributeValues:{":users":users},ExpressionAttributeNames:{"#u":"users"},ReturnValues:"ALL_NEW"}).promise()).Attributes}}module.exports=TeamsTable;

},{"aws-sdk":undefined,"uuid/v4":7}],3:[function(require,module,exports){
"use strict";const initialCategories=require("./initial-categories.json"),ProfilesTable=require("../../db/ProfilesTable"),TeamsTable=require("../../db/TeamsTable");module.exports.lambda=async event=>{const profileId=event.requestContext.authorizer.claims.sub;console.log({profileId:profileId});const{teamName}=JSON.parse(event.body);console.log({teamName:teamName});const code=await getAvailableCode();let team=await TeamsTable.createTeamAsync(code,teamName,initialCategories);return team=await TeamsTable.addProfileAsync(team.id,profileId),await ProfilesTable.addTeamAsync(team.id,profileId),{statusCode:200,body:JSON.stringify(team)}};async function getAvailableCode(){const code=Math.floor(1e6*Math.random()).toString(),teamsWithCode=await TeamsTable.queryTeamByCodeAsync(code);return 0===teamsWithCode.length?code:getAvailableCode()}

},{"../../db/ProfilesTable":1,"../../db/TeamsTable":2,"./initial-categories.json":4}],4:[function(require,module,exports){
module.exports=[
    {
        "descriptionGreen": "We're learning lots of interesting stuff all the time!",
        "descriptionRed": "We never have time to learn anything.",
        "groupId": "1",
        "id": "2",
        "image": "learning",
        "name": "Learning"
    },
    {
        "descriptionGreen": "We are in control of our own destiny! We decide what to build and how to build it.",
        "descriptionRed": "We are just pawns in a game of chess with no influence over what we build or how we build it.",
        "groupId": "1",
        "id": "8",
        "image": "pawnsOrPlayers",
        "name": "Pawns or Players"
    },
    {
        "descriptionGreen": "We get stuff done really quickly! No waiting and no delays.",
        "descriptionRed": "We never seem to get anything done. We keep getting stuck or interrupted. Stories keep getting stuck on dependencies.",
        "groupId": "1",
        "id": "9",
        "image": "speed",
        "name": "Speed"
    },
    {
        "descriptionGreen": "We are a totally gelled super-team with awesome collaboration!",
        "descriptionRed": "We are a bunch of individuals that neither know nor care about what the other people in the squad are doing. ",
        "groupId": "1",
        "id": "1",
        "image": "teamwork",
        "name": "Teamwork"
    },
    {
        "descriptionGreen": "We're proud of the quality of our code! It is clean, easy to read and has great test coverage.",
        "descriptionRed": "Our code is a pile of dung and technical debt is raging out of control.",
        "groupId": "1",
        "id": "6",
        "image": "healthOfCodebase",
        "name": "Health of Codebase"
    },
    {
        "descriptionGreen": "We love going to work and have great fun working together!",
        "descriptionRed": "Boooooooring...",
        "groupId": "1",
        "id": "5",
        "image": "fun",
        "name": "Fun"
    },
    {
        "descriptionGreen": "Releasing is simple, safe, painless and mostly automated.",
        "descriptionRed": "Releasing is risky, painful, lots of manual work and takes forever.",
        "groupId": "1",
        "id": "4",
        "image": "releasingProcess",
        "name": "Releasing process"
    },
    {
        "descriptionGreen": "We know exactly why we are here and we’re really excited about it!",
        "descriptionRed": "We have no idea why we are here, there's no high level picture or focus. Our so called mission is completely unclear and uninspiring.",
        "groupId": "1",
        "id": "7",
        "image": "mission",
        "name": "Mission"
    },
    {
        "descriptionGreen": "We always get great support and help when we ask for it!",
        "descriptionRed": "We keep getting stuck because we can't get the support and help that we ask for.",
        "groupId": "1",
        "id": "11",
        "image": "support",
        "name": "Support"
    },
    {
        "descriptionGreen": "We deliver great stuff!\nWe're proud of it and\nour stakeholders are\nreally happy. ",
        "descriptionRed": "We deliver crap. We feel\nashamed to deliver it.\nOur stakeholders hate\nus. ",
        "groupId": "1",
        "id": "3",
        "image": "deliveringValue",
        "name": "Delivering Value"
    },
    {
        "descriptionGreen": "Our way of working fits us perfectly!",
        "descriptionRed": "Our way of working sucks!",
        "groupId": "1",
        "id": "10",
        "image": "suitableProcess",
        "name": "Suitable process"
    }
]
},{}],5:[function(require,module,exports){
/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */
var byteToHex = [];
for (var i = 0; i < 256; ++i) {
  byteToHex[i] = (i + 0x100).toString(16).substr(1);
}

function bytesToUuid(buf, offset) {
  var i = offset || 0;
  var bth = byteToHex;
  // join used to fix memory issue caused by concatenation: https://bugs.chromium.org/p/v8/issues/detail?id=3175#c4
  return ([bth[buf[i++]], bth[buf[i++]], 
	bth[buf[i++]], bth[buf[i++]], '-',
	bth[buf[i++]], bth[buf[i++]], '-',
	bth[buf[i++]], bth[buf[i++]], '-',
	bth[buf[i++]], bth[buf[i++]], '-',
	bth[buf[i++]], bth[buf[i++]],
	bth[buf[i++]], bth[buf[i++]],
	bth[buf[i++]], bth[buf[i++]]]).join('');
}

module.exports = bytesToUuid;

},{}],6:[function(require,module,exports){
// Unique ID creation requires a high quality random # generator.  In node.js
// this is pretty straight-forward - we use the crypto API.

var crypto = require('crypto');

module.exports = function nodeRNG() {
  return crypto.randomBytes(16);
};

},{"crypto":undefined}],7:[function(require,module,exports){
var rng = require('./lib/rng');
var bytesToUuid = require('./lib/bytesToUuid');

function v4(options, buf, offset) {
  var i = buf && offset || 0;

  if (typeof(options) == 'string') {
    buf = options === 'binary' ? new Array(16) : null;
    options = null;
  }
  options = options || {};

  var rnds = options.random || (options.rng || rng)();

  // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`
  rnds[6] = (rnds[6] & 0x0f) | 0x40;
  rnds[8] = (rnds[8] & 0x3f) | 0x80;

  // Copy bytes to buffer, if provided
  if (buf) {
    for (var ii = 0; ii < 16; ++ii) {
      buf[i + ii] = rnds[ii];
    }
  }

  return buf || bytesToUuid(rnds);
}

module.exports = v4;

},{"./lib/bytesToUuid":5,"./lib/rng":6}]},{},[3])(3)
});
